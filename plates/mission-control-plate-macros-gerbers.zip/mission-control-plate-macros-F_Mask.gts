G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,7.0.11+dfsg-1build4*
G04 #@! TF.CreationDate,2026-06-02T17:33:43-04:00*
G04 #@! TF.ProjectId,mission-control-plate-macros,6d697373-696f-46e2-9d63-6f6e74726f6c,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.11+dfsg-1build4) date 2026-06-02 17:33:43*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.700000*%
G04 APERTURE END LIST*
D10*
X19710400Y-85598000D03*
X19710400Y-147580000D03*
X19710400Y-181500000D03*
X19700000Y-168097200D03*
X19710400Y-106222800D03*
X19710400Y-127101600D03*
M02*
